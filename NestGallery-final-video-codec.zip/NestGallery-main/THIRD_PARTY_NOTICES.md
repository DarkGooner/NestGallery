# Third-party notices

## Jellyfin Media3 FFmpeg decoder

NestGallery includes `org.jellyfin.media3:media3-ffmpeg-decoder:1.9.0+1` for FFmpeg-backed audio decoding. The Maven artifact declares the **GNU GPL v3.0** license and is based on the Jellyfin AndroidX Media3 project.

Source: https://github.com/jellyfin/jellyfin-androidx-media
License: https://www.gnu.org/licenses/gpl-3.0.txt

The decoder improves support for formats/codecs which Android's normal audio decoder may not handle, including some unusual AVI audio tracks. It does **not** replace Media3's video decoders, so a video codec unsupported by the device may still fail to play.

The rest of NestGallery's dependencies retain their own upstream licenses.


## Video compatibility fallback

NestGallery optionally uses **LibVLC-Android 3.7.0** (`org.videolan.android:libvlc-all`) as an in-app fallback when Media3 cannot decode a video. This is provided by VideoLAN and is licensed under the GNU Lesser General Public License 2.1 (LGPL-2.1).

The app keeps Media3 as the normal playback engine and hands difficult/legacy codecs (including AVI files) to libVLC automatically. The libVLC AAR and its native libraries are resolved from Maven Central at build time.

Project: https://code.videolan.org/videolan/libvlcjni
License: https://www.gnu.org/licenses/old-licenses/lgpl-2.1.en.html
